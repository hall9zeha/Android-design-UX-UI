package com.alain.cursos.top;

/**
 * Created by Alain Nicolás Tello on 19/09/2017.
 * For: CursosAndroidANT
 * All rights reserved 2017
 */

interface OnItemClickListener {
    void onItemClick(Artista artista);
    void onLongItemClick(Artista artista);
}
